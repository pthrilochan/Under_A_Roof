#!/bin/sh

# This script syncs the deployments element between 2 jboss xml's.
# The existing file is considered as source of truth for deployments
# If the new file coming from git does not have any deployments, this script will extract deployments from the existing file and add it to the file that came from git
# If the new file coming from git has any deployments, this script will delete that element and then insert deployments from existing file to the new file

existing_xml_file=$1
git_xml_file=$2

existing_xml_deployments=`sed -n '/<deployments>/,/<\/deployments>/p' $existing_xml_file`
echo "Existing Deployments"
echo $existing_xml_deployments
git_xml_deployments=`sed -n '/<deployments>/,/<\/deployments>/p' $git_xml_file`
echo "GIT Deployments"
echo $git_xml_deployments

if [ "$existing_xml_deployments" != "" ]; then
        echo "Existing xml has a deployments element"
        echo > existing.txt
        echo "$existing_xml_deployments" >> existing.txt
        echo >> existing.txt

        echo > new.txt
        echo "$git_xml_deployments" >> new.txt
        echo >> new.txt

        if [ "$git_xml_deployments" == "" ]; then
                echo "GIT Deployments is empty. Inserting deployments element from existing xml into git xml"
                sed -i '/<\/socket-binding-group>/r existing.txt' $git_xml_file
        else
                echo "GIT Deployments is NOT empty. Deleting deployments element from git xml"
                grep -xvf new.txt $git_xml_file > temp.xml
                sed -i '/<\/socket-binding-group>/r existing.txt' temp.xml
                cp temp.xml $git_xml_file
        fi
        rm -rf existing.txt new.txt temp.xml
fi

